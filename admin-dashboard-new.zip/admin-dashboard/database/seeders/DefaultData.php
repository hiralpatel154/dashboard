<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Manager;
use App\Models\Admin;

class DefaultData extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $admin =[
            'name' =>"admin",
            'email' =>"admin@gmail.com",
            'password'=>bcrypt(12345678),
            'login_at'=>date('Y-m-d H:i:s')
            
        ];
        Admin::create($admin);
        $manager =[
            'name' =>"Hiral",
            'email' =>"manager@gmail.com",
            'password'=>bcrypt(12345678),
            'login_at'=>date('Y-m-d H:i:s')
        ];
        Manager::create($manager);
    }
}
