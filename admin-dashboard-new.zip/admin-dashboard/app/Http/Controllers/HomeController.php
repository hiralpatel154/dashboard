<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    public function index(){
        return view('welcome');
    }
    public function login(){
        
        return view('frontend.login');
    }
    public function checkLogin(Request $request){
        $input = $request->all();
        $this->validate($request, [
         'email' =>'required',
         'password' =>'required|min:6',
        ]);
 
        if(Auth::guard('web')->attempt(['email' => $input['email'],'password'=>$input['password']])){
            return view('frontend.users');
        }else{
         return redirect()->back()->with('error','Password or email wrong');
        }
     }
     public function logout(){
         Auth::guard('web')->logout();
         return redirect('/');
     }
}
