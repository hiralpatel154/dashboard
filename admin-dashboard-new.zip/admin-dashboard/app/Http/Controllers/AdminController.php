<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class AdminController extends Controller
{
    public function showForm(){
        return view('admin.login');
    }
    public function checkLogin(Request $request){
        $input = $request->all();
        $this->validate($request, [
         'email' =>'required',
         'password' =>'required|min:6',
        ]);
 
        if(Auth::guard('admin')->attempt(['email' => $input['email'],'password'=>$input['password']])){
         return redirect('/dropdown');
        }else{
         return redirect()->back()->with('error','Password or email wrong');
        }
     }
     public function logout(){
         Auth::guard('admin')->logout();
         return redirect('/');
     }
}
