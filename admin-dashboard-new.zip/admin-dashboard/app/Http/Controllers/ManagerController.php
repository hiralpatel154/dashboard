<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ManagerController extends Controller
{
    public function showForm(){
        return view('manager.login');
    }
    public function checkLogin(Request $request){
        $input = $request->all();
        $this->validate($request, [
         'email' =>'required',
         'password' =>'required|min:6',
        ]);
 
        if(Auth::guard('manager')->attempt(['email' => $input['email'],'password'=>$input['password']])){
            return view('frontend.example');
        }else{
         return redirect()->back()->with('error','Password or email wrong');
        }
     }
     public function logout(){
         Auth::guard('manager')->logout();
         return redirect('/');
     }
     public function index(){
        return view('frontend.example');
    }
}
