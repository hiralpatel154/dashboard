@extends('frontend.assets.main-link')
@section('main-link-section')
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow d-flex justify-content-center">

<h1 class="text-center">Country, State, City Dropdown</h1>



</nav>
<div class="d-flex justify-content-center">
    <div>
    <h3 class="text-center mt-3">Features</h3>
    
    <ol>
        <li>Only Admin Can select Contry, State and City</li>
    </ol>

    </div>
    
   
</div>
<div class="d-flex justify-content-center">
<select class="form-select form-select-lg m-5 bg-light border border-warning rounded" aria-label=".form-select-sm example" id="role">
                <option selected>Login as</option>
                <option value="user">User</option>
                <option value="admin">Admin</option>
                <option value="manager">Manager</option>
        </select>
</div>

        
    
  
    
@endsection