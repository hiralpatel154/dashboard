@extends('frontend.layouts.main')

	@section('main-section')
	
	<!-- Begin Page Content -->
    <div class="container-fluid">
                    <div class="container mt-4" >
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="alert alert-warning mb-4 text-center">
                                <h4 >Laravel AJAX Dependent Country State City Dropdown</h4>
                                </div> 
                                <form>
                                    <div class="form-group mb-3">
                                        <select  id="country-dropdown" class="form-control">
                                            <option value="">-- Select Country --</option>
                                            @foreach ($countries as $data)
                                            <option value="{{$data->id}}">
                                                {{$data->name}}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="form-group mb-3">
                                        <select id="state-dropdown" class="form-control">
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <select id="city-dropdown" class="form-control">
                                        </select>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
	
	@endsection
               

