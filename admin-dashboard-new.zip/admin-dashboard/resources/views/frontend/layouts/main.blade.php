@include('frontend.layouts.header')
	@yield('main-section')
@include('frontend.layouts.footer')