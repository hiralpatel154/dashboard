<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DropdownController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ManagerController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('dropdown', [DropdownController::class, 'index'])->middleware("adminAuth");
Route::post('fetch-states', [DropdownController::class, 'fetchState']);
Route::post('fetch-cities', [DropdownController::class, 'fetchCity']);


Route::get('/',[HomeController::class, 'index']);
Route::get('login',[HomeController::class,'login'])->name('login');
Route::get('admin', [AdminController::class,'showform'])->name('admin');
Route::get('manager', [ManagerController::class,'showform'])->name('manager');

Route::post('manager/login', [ManagerController::class,'checkLogin'])->name('manager.login');
Route::post('admin/login', [AdminController::class,'checkLogin'])->name('admin.login');
Route::post('user/login', [HomeController::class,'checkLogin'])->name('user.login');

Route::get('admin/logout', [AdminController::class,'logout'])->name('admin.logout');
Route::get('manager/logout', [ManagerController::class,'logout'])->name('manager.logout');
Route::get('user/logout', [HomeController::class,'logout'])->name('user.logout');